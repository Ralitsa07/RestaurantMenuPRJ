﻿using Microsoft.AspNetCore.Identity;

namespace RestaurantMenuPRJ.Data.Models
{
    /// <summary>
    /// This class is used for platform ASP.NET Core 
    /// </summary>
    public class ApplicationUser : IdentityUser
    {
        // Допълнителни полета за потребител
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}

