﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents a food category in the restaurant menu system.
/// Each category groups multiple dishes (for example: Salads, Main Courses, Desserts).
/// </summary>

public partial class Category
{
    
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public virtual ICollection<Dish> Dishes { get; set; } = new List<Dish>();
}
