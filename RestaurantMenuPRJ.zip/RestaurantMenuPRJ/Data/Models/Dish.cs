﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents a dish in the restaurant menu.
/// A dish belongs to a category and can contain multiple ingredients.
/// </summary>
public partial class Dish
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public decimal Price { get; set; }

    public int CategoryId { get; set; }

    public bool IsActive { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual ICollection<DishIngredient> DishIngredients { get; set; } = new List<DishIngredient>();

    public virtual ICollection<MenuItem> MenuItems { get; set; } = new List<MenuItem>();

   // public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}
