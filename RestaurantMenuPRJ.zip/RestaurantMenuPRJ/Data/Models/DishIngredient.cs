﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents the relationship between a Dish and an Ingredient.
/// This table defines how much of a given ingredient is used in a dish.
/// </summary>
public partial class DishIngredient
{
    public int Id { get; set; }

    public int DishId { get; set; }

    public int IngredientId { get; set; }

    public decimal Quantity { get; set; }

    public virtual Dish Dish { get; set; } = null!;

    public virtual Ingredient Ingredient { get; set; } = null!;
}
