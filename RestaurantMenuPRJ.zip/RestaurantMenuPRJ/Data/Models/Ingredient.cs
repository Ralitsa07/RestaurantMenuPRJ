﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents an ingredient used in one or more dishes.
/// Ingredients can be marked as allergens for safety and labeling purposes.
/// </summary>

public partial class Ingredient
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string Unit { get; set; } = null!;

    public bool IsAllergen { get; set; }

    public virtual ICollection<DishIngredient> DishIngredients { get; set; } = new List<DishIngredient>();
}
