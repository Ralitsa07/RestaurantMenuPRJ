﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents a dish entry inside a specific menu section.
/// Controls how a dish is displayed in the menu.
/// </summary>

public partial class MenuItem
{
    public int Id { get; set; }

    public int MenuSectionId { get; set; }

    public int DishId { get; set; }

    public bool IsVisible { get; set; }

    public string? Note { get; set; }

    public virtual Dish Dish { get; set; } = null!;

    public virtual MenuSection MenuSection { get; set; } = null!;
}
