﻿using System;
using System.Collections.Generic;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents a section of the menu
/// (for example: Starters, Main Courses, Desserts, Drinks).
/// </summary>

public partial class MenuSection
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public bool IsActive { get; set; }

    public virtual ICollection<MenuItem> MenuItems { get; set; } = new List<MenuItem>();
}
