﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace RestaurantMenuPRJ.Data.Models;

/// <summary>
/// This class represents an application user.
/// Extends ASP.NET Core IdentityUser with additional profile information.
/// </summary>

public class Userr:IdentityUser
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

 
}
