﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RestaurantMenuPRJ.Data.Models;
using RestaurantMenuPRJ.ViewModels;

namespace RestaurantMenuPRJ.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly UserManager<Userr> _userManager;
        private readonly SignInManager<Userr> _signInManager;
        private readonly ILogger<RegisterModel> _logger;

        public RegisterModel(
            UserManager<Userr> userManager,
            SignInManager<Userr> signInManager,
            ILogger<RegisterModel> logger)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        [BindProperty]
        public RegisterViewModel Input { get; set; }

        public string ReturnUrl { get; set; }



       
        public List<string> AvailableRoles { get; set; }


        public void OnGet(string returnUrl = null)
        {
            ReturnUrl = returnUrl;
          
            AvailableRoles = new List<string> { "User", "Manager" };
        }
        public async Task<IActionResult> OnPostAsync(string returnUrl = null)
        {
            returnUrl ??= Url.Content("~/");

            if (ModelState.IsValid)
            {
                var user = new Userr
                {
                    UserName = Input.Email,
                    Email = Input.Email,
                    CreatedAt = DateTime.UtcNow
                };

                var result = await _userManager.CreateAsync(user, Input.Password);

                if (result.Succeeded)
                {
                    _logger.LogInformation("User created with password.");
                   
                    await _userManager.AddToRoleAsync(user, Input.Role);

                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return LocalRedirect(returnUrl);
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }

            AvailableRoles = new List<string> { "User", "Manager" };
            return Page();
        }
    }
}
