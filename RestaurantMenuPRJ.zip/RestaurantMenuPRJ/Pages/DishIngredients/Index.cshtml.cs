using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RestaurantMenuPRJ.Data.Models;

namespace RestaurantMenuPRJ.Pages_DishIngredients
{
    public class IndexModel : PageModel
    {
        private readonly RestaurantMenuPRJ.Data.Models.RestaurantMenuContext _context;

        public IndexModel(RestaurantMenuPRJ.Data.Models.RestaurantMenuContext context)
        {
            _context = context;
        }

        public IList<DishIngredient> DishIngredient { get;set; } = default!;

        public async Task OnGetAsync()
        {
            DishIngredient = await _context.DishIngredients
                .Include(d => d.Dish)
                .Include(d => d.Ingredient).ToListAsync();
        }
    }
}
