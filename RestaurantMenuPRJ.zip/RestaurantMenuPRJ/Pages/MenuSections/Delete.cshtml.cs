using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RestaurantMenuPRJ.Data.Models;

namespace RestaurantMenuPRJ.Pages_MenuSections
{
    [Authorize(Roles = "Admin")]
    public class DeleteModel : PageModel
    {
        private readonly RestaurantMenuPRJ.Data.Models.RestaurantMenuContext _context;

        public DeleteModel(RestaurantMenuPRJ.Data.Models.RestaurantMenuContext context)
        {
            _context = context;
        }

        [BindProperty]
        public MenuSection MenuSection { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menusection = await _context.MenuSections.FirstOrDefaultAsync(m => m.Id == id);

            if (menusection == null)
            {
                return NotFound();
            }
            else
            {
                MenuSection = menusection;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menusection = await _context.MenuSections.FindAsync(id);
            if (menusection != null)
            {
                MenuSection = menusection;
                _context.MenuSections.Remove(MenuSection);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
