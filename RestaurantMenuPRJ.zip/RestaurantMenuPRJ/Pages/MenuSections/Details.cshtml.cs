using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RestaurantMenuPRJ.Data.Models;

namespace RestaurantMenuPRJ.Pages_MenuSections
{
    public class DetailsModel : PageModel
    {
        private readonly RestaurantMenuPRJ.Data.Models.RestaurantMenuContext _context;

        public DetailsModel(RestaurantMenuPRJ.Data.Models.RestaurantMenuContext context)
        {
            _context = context;
        }

        public MenuSection MenuSection { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menusection = await _context.MenuSections.FirstOrDefaultAsync(m => m.Id == id);
            if (menusection == null)
            {
                return NotFound();
            }
            else
            {
                MenuSection = menusection;
            }
            return Page();
        }
    }
}
