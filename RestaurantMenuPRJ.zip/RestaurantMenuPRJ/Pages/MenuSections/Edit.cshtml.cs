using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RestaurantMenuPRJ.Data.Models;

namespace RestaurantMenuPRJ.Pages_MenuSections
{
    [Authorize(Roles = "Manager,Admin")]
    public class EditModel : PageModel
    {
        private readonly RestaurantMenuPRJ.Data.Models.RestaurantMenuContext _context;

        public EditModel(RestaurantMenuPRJ.Data.Models.RestaurantMenuContext context)
        {
            _context = context;
        }

        [BindProperty]
        public MenuSection MenuSection { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menusection =  await _context.MenuSections.FirstOrDefaultAsync(m => m.Id == id);
            if (menusection == null)
            {
                return NotFound();
            }
            MenuSection = menusection;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(MenuSection).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MenuSectionExists(MenuSection.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool MenuSectionExists(int id)
        {
            return _context.MenuSections.Any(e => e.Id == id);
        }
    }
}
