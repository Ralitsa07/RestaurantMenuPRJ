using Microsoft.EntityFrameworkCore;
using RestaurantMenuPRJ.Data.Models;
using Microsoft.AspNetCore.Identity;
using static System.Formats.Asn1.AsnWriter;

namespace RestaurantMenuPRJ
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddRazorPages();

            builder.Services.AddDbContext<RestaurantMenuContext>(options =>
      options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // Identity ������������ - �����: ��������� ApplicationUser, �� IdentityUser!
            builder.Services.AddIdentity<Userr, IdentityRole>(options =>
            {
                // ��������� �� ��������
                options.Password.RequireDigit = true;
                options.Password.RequireLowercase = true;
                options.Password.RequireUppercase = true;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequiredLength = 6;

                // ��������� �� �����������
                options.User.RequireUniqueEmail = true;

                // ��������� �� ���������� �� ������
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
                options.Lockout.MaxFailedAccessAttempts = 5;
            })
            .AddEntityFrameworkStores<RestaurantMenuContext>()
            .AddDefaultTokenProviders();

            // ������������ �� cookie �� Razor Pages
            builder.Services.ConfigureApplicationCookie(options =>
            {
                options.LoginPath = "/Account/Login";        // ��� ��� Login ��������
                options.LogoutPath = "/Account/Logout";      // ��� ��� Logout
                options.AccessDeniedPath = "/Account/AccessDenied";  // ������ �������
                options.ExpireTimeSpan = TimeSpan.FromHours(24);
                options.SlidingExpiration = true;
            });


            var app = builder.Build();

            // Seed ���� ��� ����������
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                SeedRolesAsync(services).GetAwaiter().GetResult();
                SeedAdminUserAsync(services).GetAwaiter().GetResult();
                //  await SeedRolesAsync(services);
            }


            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            //app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();  // ��������
            app.UseAuthorization();

            app.MapRazorPages();

            app.Run();
        }
        // ����� �� ��������� �� ����
        private static async Task SeedRolesAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            string[] roleNames = { "Admin", "Manager", "User" };
            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }
        }
        private static async Task SeedAdminUserAsync(IServiceProvider serviceProvider)
        {
            var userManager = serviceProvider.GetRequiredService<UserManager<Userr>>();
            var logger = serviceProvider.GetRequiredService<ILogger<Program>>();

            string adminEmail = "admin@catalog.com";
            string adminPassword = "Admin123!";

            var adminUser = await userManager.FindByEmailAsync(adminEmail);

            if (adminUser == null)
            {
                var user = new Userr
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    EmailConfirmed = true,
                    CreatedAt = DateTime.UtcNow
                   // Role = "Admin"
                };

                var result = await userManager.CreateAsync(user, adminPassword);

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(user, "Admin");
                    logger.LogInformation($"Admin ���������� ��������: {adminEmail}");
                }
                else
                {
                    logger.LogError("������ ��� ��������� �� Admin ����������");
                }
            }
        }
    }
}